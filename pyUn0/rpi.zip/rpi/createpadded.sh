cat v1.1.bin /dev/zero | dd bs=1024 count=2048 of=padded.bin
