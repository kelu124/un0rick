gpio mode 10 IN 
gpio mode 11 IN 
gpio mode 12 IN 
gpio mode 13 IN 
gpio mode 14 IN 
gpio mode 3 OUT 
gpio write 3 0 
gpio mode 3 OUT
gpio write 3 1

gpio mode 10 ALT0 
gpio mode 11 OUT 
gpio write 11 1
gpio mode 12 ALT0 
gpio mode 13 ALT0 
gpio mode 14 ALT0 


