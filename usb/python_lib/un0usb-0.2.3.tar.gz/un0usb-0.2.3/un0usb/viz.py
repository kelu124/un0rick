'''
Wrapper for viz
'''

import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import datetime

class FView(object):

    def readfile(self,npzPath):
        """Reads NPZ"""