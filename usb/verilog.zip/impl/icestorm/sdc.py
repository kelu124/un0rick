ctx.addClock("ref_clk", 12)
ctx.addClock("pulser_clk", 128)
ctx.addClock("sys_clk", 64)
ctx.addClock("vga_clk", 36)